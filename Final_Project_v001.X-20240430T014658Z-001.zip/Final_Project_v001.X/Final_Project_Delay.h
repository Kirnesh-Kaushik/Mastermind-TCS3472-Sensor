#ifndef FINAL_PROJECT_DELAY_H
#define	FINAL_PROJECT_DELAY_H

#ifdef	__cplusplus
extern "C" {
#endif
void delay_ms(unsigned int ms);



#ifdef	__cplusplus
}
#endif

#endif	/* FINAL_PROJECT_DELAY_H */

