#ifndef FINAL_PROJECT_BUTTON_H
#define	FINAL_PROJECT_BUTTON_H

#ifdef	__cplusplus
extern "C" {
#endif

void initializeButton();
void get_color_inputs(void);


#ifdef	__cplusplus
}
#endif

#endif	/* FINAL_PROJECT_BUTTON_H */

